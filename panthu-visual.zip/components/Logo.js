/* eslint-disable @next/next/no-img-element */
function Imagem({ nome, className, alt = '' }) {
  return (
    <picture>
      <source srcSet={`/${nome}-claro.png`} media="(prefers-color-scheme: dark)" />
      <img className={className} src={`/${nome}.png`} alt={alt} />
    </picture>
  );
}
export default function Logo({ completo = false }) {
  if (completo) return <Imagem nome="logo-completo" className="logo-completo" alt="Panthu — Liberdade para pertencer" />;
  return (
    <span className="marca-logo" role="img" aria-label="Panthu">
      <Imagem nome="logo-simbolo" className="simb" />
      <Imagem nome="logo-nome" className="nome" />
    </span>
  );
}
