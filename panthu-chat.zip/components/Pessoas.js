'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { criarCliente } from '@/lib/supabase/client';
import './chat.css';

export default function Pessoas({ lista, euId }) {
  const [aberto, setAberto] = useState(null);
  const [msg, setMsg] = useState(null);
  const router = useRouter();
  const sb = criarCliente();

  async function conversar(id) {
    const { data, error } = await sb.rpc('iniciar_conversa', { outro: id });
    if (error) return setMsg({ t: 'erro', m: 'Não foi possível iniciar a conversa.' });
    router.push(`/app/chat/${data}`);
  }
  async function denunciar(e, id) {
    e.preventDefault();
    const motivo = String(new FormData(e.target).get('motivo'));
    const { error } = await sb.rpc('denunciar_usuario', { p_usuario: id, p_motivo: motivo });
    setAberto(null);
    setMsg(error ? { t: 'erro', m: 'Não foi possível enviar. Descreva o motivo com pelo menos 5 caracteres.' } : { t: 'ok', m: 'Denúncia enviada. A equipe vai analisar.' });
  }

  return (<div>
    {msg && <div className={`msg ${msg.t}`} role="status">{msg.m}</div>}
    {lista.map(p => (
      <div key={p.usuario_id}>
        <div className="pessoa-linha">
          <div className="pessoa"><i>{p.inicial}</i>{p.nome}</div>
          {p.usuario_id !== euId && (<div style={{ display: 'flex', gap: 6 }}>
            <button className="btn s mini" onClick={() => conversar(p.usuario_id)}>Conversar</button>
            <button className="btn o mini" onClick={() => setAberto(aberto === p.usuario_id ? null : p.usuario_id)}>Denunciar</button>
          </div>)}
        </div>
        {aberto === p.usuario_id && (
          <form onSubmit={(e) => denunciar(e, p.usuario_id)} style={{ padding: '8px 0' }}>
            <textarea name="motivo" required minLength={5} maxLength={500} placeholder="Descreva o comportamento inadequado" />
            <button className="btn p mini" style={{ marginTop: 6 }}>Enviar denúncia</button>
          </form>
        )}
      </div>
    ))}
  </div>);
}
