import Link from 'next/link';
import { criarServidor } from '@/lib/supabase/server';
export const dynamic = 'force-dynamic';
const rotulo = { evento: 'Evento', privada: 'Conversa', grupo: 'Grupo' };
export default async function Chat() {
  const sb = await criarServidor();
  const { data } = await sb.rpc('minhas_conversas');
  return (<>
    <h1 style={{ fontSize: 32 }}>Chat</h1>
    {(!data || !data.length) && <div className="card vazio"><h3>Nenhuma conversa ainda</h3><p>Confirme presença em um encontro para entrar no chat dele e conversar com quem vai.</p></div>}
    {(data || []).map(c => (
      <Link key={c.sala_id} href={`/app/chat/${c.sala_id}`} className="card" style={{ display: 'block', textDecoration: 'none', color: 'inherit' }}>
        <b>{c.titulo}</b> <span className="tag">{rotulo[c.tipo] || c.tipo}</span>
        {c.ultima && <><br /><small style={{ color: 'var(--suave)' }}>Última mensagem: {new Date(c.ultima).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short', timeZone: 'America/Sao_Paulo' })}</small></>}
      </Link>
    ))}
  </>);
}
